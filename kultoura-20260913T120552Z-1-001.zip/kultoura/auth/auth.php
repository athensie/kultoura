<?php
session_start();
require_once '../config/dbmain.php';

/*
 |--------------------------------------------------------------------
 | BASE URL
 |--------------------------------------------------------------------
 | This file lives in /kultoura/auth/, so a bare header("Location: login.php")
 | resolves relative to /auth/ — which is exactly why admins were landing
 | on /kultoura/auth/admindashboard.php instead of /kultoura/admin/admindashboard.php.
 | Anchoring every redirect to a fixed base path fixes that regardless of
 | which folder a script is called from. Keep this in sync with the same
 | constant in login.php / admindashboard.php.
 */
define('BASE_URL', '/kultoura');

/* ─────────────────────────────────────────────
   TABLE STRUCTURE (confirmed):

   `admins` table:
     admin_id, first_name, last_name, username, email,
     password (hashed), role, status, last_login,
     created_at, updated_at

   `users` table:
     id, fullname, username, email, password (hashed),
     promotional_email, created_at
───────────────────────────────────────────── */

$action = $_GET['action'] ?? ($_POST['action'] ?? '');

/*
 |--------------------------------------------------------------------
 | LOGOUT
 |--------------------------------------------------------------------
 | The sidebar "Log Out" link hits this as a GET request
 | (auth.php?action=logout). Clear the session completely, then send
 | everyone — admin, super admin, or regular user — to the site root.
 */
if ($action === 'logout') {
    $_SESSION = [];

    // Also remove the session cookie itself, not just its contents.
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_unset();
    session_destroy();

    header("Location: " . BASE_URL . "/index.php");
    exit;
}

/*
 |--------------------------------------------------------------------
 | SIGNUP
 |--------------------------------------------------------------------
 | The signup form (auth/signup.php) posts here with action=signup.
 | Validate, check for duplicates, hash the password, insert into
 | `users`, then log the new user straight in.
 |
 | NOTE: adjust the "../auth/signup.php" redirect targets below if
 | your signup page file is actually named something else.
 */
if ($action === 'signup') {
    $fullname = trim($_POST['fullname'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    $promo    = isset($_POST['promotional_email']) ? 1 : 0;

    // Required fields
    if ($fullname === '' || $username === '' || $email === '' || $password === '') {
        $_SESSION['error'] = 'Please fill in all required fields.';
        header("Location: " . BASE_URL . "/auth/signup.php");
        exit;
    }

    // Match server-side rules with the HTML pattern attributes on the form
    if (!preg_match('/^[A-Za-z\s.\'-]+$/', $fullname)) {
        $_SESSION['error'] = 'Full name should only contain letters.';
        header("Location: " . BASE_URL . "/auth/signup.php");
        exit;
    }

    if (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $username)) {
        $_SESSION['error'] = 'Username can only contain letters, numbers, and underscores (3–20 characters).';
        header("Location: " . BASE_URL . "/auth/signup.php");
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = 'Please enter a valid email address.';
        header("Location: " . BASE_URL . "/auth/signup.php");
        exit;
    }

    if (strlen($password) < 6) {
        $_SESSION['error'] = 'Password must be at least 6 characters.';
        header("Location: " . BASE_URL . "/auth/signup.php");
        exit;
    }

    if ($password !== $confirm) {
        $_SESSION['error'] = 'Passwords do not match.';
        header("Location: " . BASE_URL . "/auth/signup.php");
        exit;
    }

    // Check for existing username or email before inserting
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
    $stmt->bind_param('ss', $username, $email);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($existing) {
        $_SESSION['error'] = 'That username or email is already taken.';
        header("Location: " . BASE_URL . "/auth/signup.php");
        exit;
    }

    $hashed = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (fullname, username, email, password, promotional_email) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('ssssi', $fullname, $username, $email, $hashed, $promo);

    if ($stmt->execute()) {
        $newUserId = $stmt->insert_id;
        $stmt->close();

        // Log the new user straight in
        $_SESSION['user_id']   = $newUserId;
        $_SESSION['username']  = $username;
        $_SESSION['role']      = 'User';
        $_SESSION['user_name'] = $fullname;

        header("Location: " . BASE_URL . "/index.php");
        exit;
    } else {
        $stmt->close();
        $_SESSION['error'] = 'Something went wrong creating your account. Please try again.';
        header("Location: " . BASE_URL . "/auth/signup.php");
        exit;
    }
}

if ($action !== 'login') {
    header("Location: " . BASE_URL . "/auth/login.php");
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    $_SESSION['error'] = 'Please enter both username and password.';
    header("Location: " . BASE_URL . "/auth/login.php");
    exit;
}

/* ── Try admins table first ── */
$stmt = $conn->prepare("SELECT admin_id, username, password, role, first_name, last_name FROM admins WHERE username = ? LIMIT 1");
$stmt->bind_param('s', $username);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

if ($admin && password_verify($password, $admin['password'])) {
    $_SESSION['user_id']   = $admin['admin_id'];
    $_SESSION['username']  = $admin['username'];
    $_SESSION['role']      = $admin['role'];
    $_SESSION['user_name'] = trim($admin['first_name'] . ' ' . $admin['last_name']);

    header("Location: " . BASE_URL . "/admin/admindashboard.php");
    exit;
}

/* ── Fall back to users table ── */
$stmt = $conn->prepare("SELECT id, username, password, fullname FROM users WHERE username = ? LIMIT 1");
$stmt->bind_param('s', $username);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id']   = $user['id'];
    $_SESSION['username']  = $user['username'];
    $_SESSION['role']      = 'User';
    $_SESSION['user_name'] = $user['fullname'];

    header("Location: " . BASE_URL . "/index.php");
    exit;
}

/* ── Neither table matched ── */
$_SESSION['error'] = 'Invalid username or password.';
header("Location: " . BASE_URL . "/auth/login.php");
exit;